
public class Cuadrado extends Rectangulo
{
    public Cuadrado(){
        changeLado1(30);
        changeLado2(30);
        moveHorizontal(50);
    }
    
}



