
public class Main
{
    public static void main(String[] args){
        Rectangulo fig1= new Rectangulo();
        fig1.hacerVisible();
        
        Cuadrado fig2= new Cuadrado();
        fig2.hacerVisible();
        
                
    }
}
