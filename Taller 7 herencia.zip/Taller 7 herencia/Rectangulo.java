import java.awt.*;
/**
 * Write a description of class Rectangulo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Rectangulo extends Figura
{
    private int height;
    private int width;
    private int lado1;
    private int lado2;
    // instance variables - replace the example below with your own
    public Rectangulo()
    {
        this.lado1 = 30;
        this.lado2 = 30;
        super.xPosition = 60;
        super.yPosition = 50;
        super.color = "red";
        super.isVisible = false;
    }
    
    public void esperar(int n){
        super.esperar(n);
    }
    
    public void hacerVisible(){
        super.isVisible = true;
        draw();
    }
    
     public void hacerInvisible(){
        super.erase();
    }
    
    public void moveRight()
    {
        moveHorizontal(20);
    }

    public void moveLeft()
    {
        moveHorizontal(-20);
    }

    public void moveUp()
    {
        moveVertical(-20);
    }

    public void moveDown()
    {
        moveVertical(20);
    }
    
    public void moveHorizontal(int distance)
    {
        super.erase();
        xPosition += distance;
        draw();
    }

    public void moveVertical(int distance)
    {
        super.erase();
        yPosition += distance;
        draw();
    }

    public void slowMoveHorizontal(int distance)
    {
        int delta;

        if(distance < 0) 
        {
            delta = -1;
            distance = -distance;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distance; i++)
        {
            xPosition += delta;
            draw();
        }
    }
    
    public void slowMoveVertical(int distance)
    {
        int delta;

        if(distance < 0) 
        {
            delta = -1;
            distance = -distance;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distance; i++)
        {
            yPosition += delta;
            draw();
        }
    }
    
    public void changeLado1(int l)
    {
        super.erase();
        this.lado1 = l;
        draw();
    }
    
    public void changeLado2(int l)
    {
        super.erase();
        this.lado2 = l;
        draw();
    }
        
    public void changeColor(String newColor)
    {
        color = newColor;
        draw();
    }
   
    private void draw()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                    new Rectangle(xPosition, yPosition, lado1, lado2));
            canvas.wait(10);
        }
    }
    
    
}

