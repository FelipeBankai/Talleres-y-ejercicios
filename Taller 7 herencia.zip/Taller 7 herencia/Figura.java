
/**
 * Write a description of class Figura here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Figura
{
    int xPosition;
    int yPosition;
    String color;
    boolean isVisible;
    
    void erase()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
     public void makeInvisible()
    {
        erase();
        isVisible = false;
    } 
    
    public void esperar(int n)
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.wait(n);
        }
    }
    
}