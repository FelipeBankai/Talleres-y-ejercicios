/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

/**
 *
 * @author Alumno
 */
public class CongeladoXagua extends ProductoCongelado{
    
    private String infoSalinidad;

    public CongeladoXagua(String caducidad, int lote, String fechaEnvase, String pais, int temperatura, String infoSalinidad) {
        super(caducidad, lote, fechaEnvase, pais, temperatura);
        this.infoSalinidad=infoSalinidad;
    }

    public String getInfoSalinidad() {
        return infoSalinidad;
    }

    public void setInfoSalinidad(String infoSalinidad) {
        this.infoSalinidad = infoSalinidad;
    }

    @Override
    public String toString() {
        return "Producto congelado por agua " + super.toString() + "\ninformación de la salinidad del agua con que se realizó la congelación en gramos de sal por litro de agua=" + infoSalinidad ;
    }
    
    
}
