/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Prueba {
    
    
    public void main() {
        ProductoFresco infoFresco1=new ProductoFresco("15 de julio de 2017", 456, "15 de junio de 2017", "Chile" );
        ProductoFresco infoFresco2=new ProductoFresco("20 de agosto, 2017", 421, "28 de junio de 2017", "Chile" );
    
        ProductoRefrigerado infoRefri1=new ProductoRefrigerado("12 de diciembre de 2017", 594, 15, -10, "19 de marzo de 2017", "Chile");
        ProductoRefrigerado infoRefri2=new ProductoRefrigerado("12 de noviembre de 2017", 527, 27, -9, "19 de mayo de 2017", "Chile");
        ProductoRefrigerado infoRefri3=new ProductoRefrigerado("31 de diciembre de 2017", 545, 07, 10, "05 de abril de 2017", "Chile");
        
        CongeladoXaire infoXaire1=new CongeladoXaire("12 de diciembre de 2018", 345, "10 de octubre de 2016", "Chile", -1, 40.3, 34.56, 10.1, 15.04);
        CongeladoXaire infoXaire2=new CongeladoXaire("24 de agosto de 2019", 345, "11 de julio de 2017", "Chile", -1, 26.03, 24.2, 9.6, 40.17);
        
    
        CongeladoXagua infoXagua1=new CongeladoXagua("3 de enero de 2020", 225, "20 de julio de 2017", "Chile", -3, "Informacion correspondiente a la salanilidad del producto N. Lote 225");
        CongeladoXagua infoXagua2=new CongeladoXagua("6 de septiembre de 2019", 290, "4 de enero de 2017", "Chile", -3, "Informacion correspondiente a la salanilidad del producto N. Lote 290");
    
        CongeladoXnitro infoXnitro=new CongeladoXnitro("14 de noviembre de 2021", 105, "15 de noviembre de 2016", "Chile", -5, "Informacion correspondiente al metodo de congelacion", 56);
    
        System.out.println(infoFresco1.toString());
        System.out.println("");
        System.out.println(infoFresco2.toString());
        System.out.println("");
        System.out.println(infoRefri1.toString());
        System.out.println("");
        System.out.println(infoRefri2.toString());
        System.out.println("");
        System.out.println(infoRefri3.toString());
        System.out.println("");
        System.out.println(infoXaire1.toString());
        System.out.println("");
        System.out.println(infoXaire2.toString());
        System.out.println("");
        System.out.println(infoXagua1.toString());
        System.out.println("");
        System.out.println(infoXagua2.toString());
        System.out.println("");
        System.out.println(infoXnitro.toString());
    }
}
    

