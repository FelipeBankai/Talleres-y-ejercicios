/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

/**
 *
 * @author Alumno
 */
public class ProductoFresco extends Producto{
    
    private String FechaEnvasado;
    private String Pais;

    public ProductoFresco(String caducidad, int lote, String FechaEnvasado, String Pais) {
        super(caducidad, lote);
        this.FechaEnvasado=FechaEnvasado;
        this.Pais=Pais;
    }

    public String getFechaEnvasado() {
        return FechaEnvasado;
    }

    public void setFechaEnvasado(String FechaEnvasado) {
        this.FechaEnvasado = FechaEnvasado;
    }

    public String getPais() {
        return Pais;
    }

    public void setPais(String Pais) {
        this.Pais = Pais;
    }

    @Override
    public String toString() {
        return "Producto Fresco" + super.toString() + "FechaEnvasado=" + FechaEnvasado + "\nPais=" + Pais  ;
    }
    

    

    
}
