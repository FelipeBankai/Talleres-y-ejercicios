/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

/**
 *
 * @author Alumno
 */
public abstract class Producto {
    protected String caducidad;
    protected int lote;

    public Producto(String caducidad, int lote) {
        this.caducidad = caducidad;
        this.lote = lote;
    }

    public String getCaducidad() {
        return caducidad;
    }

    

    public void setCaducidad(String caducidad) {
        this.caducidad = caducidad;
    }

    public int getLote() {
        return lote;
    }

    public void setLote(int Lote) {
        this.lote = lote;
    }

    @Override
    public String toString() {
        return  "\ncaducidad=" + caducidad + "\nlote=" + lote + "\n";
    }
    
}
