/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

/**
 *
 * @author Alumno
 */
public class ProductoRefrigerado extends Producto{
    private int codigo;
    private int temperatura;
    private String fechaEnvasado;
    private String pais;

    public ProductoRefrigerado(String caducidad, int lote, int codigo, int temperatura, String fechaEnvasado, String pais) {
        super(caducidad, lote);
        this.codigo=codigo;
        this.temperatura=temperatura;
        this.fechaEnvasado=fechaEnvasado;
        this.pais=pais;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getFechaEnvasado() {
        return fechaEnvasado;
    }

    public void setFechaEnvasado(String fechaEnvasado) {
        this.fechaEnvasado = fechaEnvasado;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    @Override
    public String toString() {
        return "Product oRefrigerado " + super.toString() + "codigo del organismo de supervisión alimentaria=" + codigo + "\ntemperatura=" + temperatura + "\nfechaEnvasado=" + fechaEnvasado + "\npais=" + pais ;
    }
    
    
}
