/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

/**
 *
 * @author Alumno
 */
public class ProductoCongelado extends Producto{
    protected String pais;
    protected int temperatura;

    public ProductoCongelado(String caducidad, int lote, String fechaEnvase, String pais, int temperatura) {
        super(caducidad, lote);
        this.pais=pais;
        this.temperatura=temperatura;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }

    @Override
    public String toString() {
        return  "\npais=" + pais + "\ntemperatura=" + temperatura ;
    }
    
    
    
}
