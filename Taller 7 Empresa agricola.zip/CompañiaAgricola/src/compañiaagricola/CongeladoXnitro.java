/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

/**
 *
 * @author Alumno
 */
public class CongeladoXnitro extends ProductoCongelado{
    
    private String metodoCongelacion;
    private int tiempoExpo;

    public CongeladoXnitro(String caducidad, int lote, String fechaEnvase, String pais, int temperatura,
            String metodoCongelacion, int tiempoExpo) {
        super(caducidad, lote, fechaEnvase, pais, temperatura);
        this.metodoCongelacion=metodoCongelacion;
        this.tiempoExpo=tiempoExpo;
    }

    public String getMetodoCongelacion() {
        return metodoCongelacion;
    }

    public void setMetodoCongelacion(String metodoCongelacion) {
        this.metodoCongelacion = metodoCongelacion;
    }

    public int getTiempoExpo() {
        return tiempoExpo;
    }

    public void setTiempoExpo(int tiempoExpo) {
        this.tiempoExpo = tiempoExpo;
    }

    @Override
    public String toString() {
        return "Productos congelados por nitrogeno " + super.toString() + "\nmetodoCongelacion=" + metodoCongelacion + "\ntiempoExpo=" + tiempoExpo + "segundos";
    }
    
}
