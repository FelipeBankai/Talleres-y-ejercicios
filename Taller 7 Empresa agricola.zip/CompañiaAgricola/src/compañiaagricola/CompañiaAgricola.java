package compañiaagricola;

public class CompañiaAgricola {

    public static void main(String[] args) {
        Prueba mostrar = new Prueba ();
        mostrar.main();
        
    }
    
}
