/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compañiaagricola;

/**
 *
 * @author Alumno
 */
public class CongeladoXaire extends ProductoCongelado{
    private double porNitro;
    private double porOxigeno;
    private double porCarbono;
    private double porVapor;

    public CongeladoXaire(String caducidad, int lote, String fechaEnvase, String pais, int temperatura,
            double porNitro, double porOxigeno, double porCarbono, double porVapor) {
        super(caducidad, lote, fechaEnvase, pais, temperatura);
        this.porNitro=porNitro;
        this.porOxigeno=porOxigeno;
        this.porCarbono=porCarbono;
        this.porVapor=porVapor;
    }

    public double getPorNitro() {
        return porNitro;
    }

    public void setPorNitro(double porNitro) {
        this.porNitro = porNitro;
    }

    public double getPorOxigeno() {
        return porOxigeno;
    }

    public void setPorOxigeno(double porOxigeno) {
        this.porOxigeno = porOxigeno;
    }

    public double getPorCarbono() {
        return porCarbono;
    }

    public void setPorCarbono(double porCarbono) {
        this.porCarbono = porCarbono;
    }

    public double getPorVapor() {
        return porVapor;
    }

    public void setPorVapor(double porVapor) {
        this.porVapor = porVapor;
    }

    @Override
    public String toString() {
        return "Producto congelado por aire" + super.toString()  + "\nporcentaje de nitrogeno=" + porNitro +"%"+ "\nporcentaje de oxigeno=" + porOxigeno +"%"+ "\nporcentaje de dioxido de carbono=" + porCarbono +"%"+ "\nporcentaje de vapor de agua=" + porVapor +"%";
    }


    

    
}
