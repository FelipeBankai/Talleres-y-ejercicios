/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioopcional;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class EjercicioOpcional {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Ingrese valores entre 100 y 200");
        int n=sc.nextInt();
        if(n>=100 && n<=200){
            Lista lista=new Lista(n);
            lista.aleatorio(n);
            lista.pares(n);
            lista.impares(n);
            lista.promedio(n);
            lista.ordenar(n);
            lista.contarMayor(n);
        }else{
            valorErroneo();
        }
        
        
    }
    public static void valorErroneo(){
        System.out.println("Usted no ha entregado un valor establecido");
        System.out.println("Finalizando programa");
    }
}
