/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioopcional;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Lista {
    private int numeros[];

    public Lista(int n) {
        numeros = new int[n];
    }

    public int[] getNumeros() {
        return numeros;
    }

    public void setNumeros(int[] numeros) {
        this.numeros = numeros;
    }
    
    
    public void aleatorio(int n){
        for(int i=0;i<n;i++){
            numeros[i]=(int)((Math.random()*100)+100);
        }
    }
    public void pares(int n){
        int pares=0;
        for(int i=0;i<n;i++){
            if(numeros[i]%2==0){
                pares++;
            }
        }
        System.out.println("Cantidad de numeros pares "+pares);
    }
    public void impares(int n){
        int impares=0;
        for(int i=0;i<n;i++){
            if(numeros[i]%2!=0){
                impares++;
            }
        }
        System.out.println("Cantidad de numeros impares "+impares);
    }
    public void promedio(int n){
        int promedio=0;
        for(int i=0;i<n;i++){
            promedio=promedio+numeros[i];
        }
        promedio=promedio/n;
        System.out.println("El promedio entre las notas es de "+promedio);
    }
    public void ordenar(int n){
        int aux=0;
        System.out.println("Lista de mayor a menor ");
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(numeros[i]<numeros[j]){
                    aux=numeros[i];
                    numeros[i]=numeros[j];
                    numeros[j]=aux;
                }
            }
            System.out.println(numeros[i]);
        }
    }
    public int buscarMayor(int n){
        int mayor=0;
        for(int i=0;i<n;i++){
            if(numeros[i]>mayor){
                mayor=numeros[i];
            }
        }
        return mayor;
    }
    public void contarMayor(int n){
        int cont=0;
        for(int i=0;i<n;i++){
            if(buscarMayor(n)==numeros[i]){
                cont++;
            }
        }
        System.out.println(buscarMayor(n)+ " Se repite "+cont);
    }
    
    
}
