/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller6estudio6;

import static com.sun.org.apache.xalan.internal.lib.ExsltMath.random;
import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.Scanner;
import static jdk.nashorn.internal.objects.NativeMath.random;

/**
 *
 * @author Alumno
 */
public class Taller6Estudio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        String nombreSara="Sara";
        int sueldoSara=28000;
        int contraSara=3485;
        Persona Sara=new Persona(nombreSara, sueldoSara, contraSara);
        
        String nombreJoel="Joel";
        int sueldoJoel=310000;
        int contraJoel=9175;
        Persona Joel=new Persona(nombreJoel, sueldoJoel, contraJoel);
        
        String nombreCaro="Carolina";
        int sueldoCaro=780000;
        int contraCaro=1917;
        Persona Carolina=new Persona(nombreCaro, sueldoCaro, contraCaro);
        
        System.out.println("Ingrese un nombre para una nueva persona");
        String nombreUsuario=sc.nextLine();
        System.out.println("Ingrese un sueldo");
        int sueldoUsuario=sc.nextInt();
        System.out.println("Ingrese una contraseña");
        int contraUsuario=sc.nextInt();
        Persona Usuario=new Persona(nombreUsuario,sueldoUsuario,contraUsuario);
        
        System.out.println("Contraseña de dos usuarios?");
        System.out.println("Ingrese el numero de algun usuario del 1 al 4");
        for(int i=0;i<2;i++){
            int primerPersona=sc.nextInt();
            if(primerPersona==1){
                System.out.println("Contraseña de Sara es "+Sara.getContraseña());
            }
            if(primerPersona==2){
                System.out.println("Contraseña de Joel es "+Joel.getContraseña());
            }
            if(primerPersona==3){
                System.out.println("Contraseña de Carolina es "+Carolina.getContraseña());
            }
            if(primerPersona==4){
                System.out.println("Contraseña de "+Usuario.getNombre()+" es "+Usuario.getContraseña());
            }
        }
        
    }
    public static int entero(){
        Scanner sc=new Scanner(System.in);
        int i=0;
        try{
            return sc.nextInt();
        }catch(Exception e){
            System.out.println("Ingresa un numero entero Valido...");
            return -1;
        }
    }
    public static int contrasena(){
        Scanner sc=new Scanner(System.in);
        int i=0;
        try{
            i=sc.nextInt();
        }catch(Exception e){
            System.out.println("Ingresa una contraseña de 4 digitos valida...");
            i=0;
        }
        if(i<=999 || i>=10000){
            System.out.println("Ingresa una contraseña de 4 digitos valida...");
        }
        return i;
    }
    public static boolean coordenada(Persona p){
      
        
        
        int cord1=(int)(Math.random()*p.getTarjeta().getTarjeta()[0].length+1);
        int cord2=(int)(Math.random()*p.getTarjeta().getTarjeta().length+1);
        
        
        return true;
    }
}
