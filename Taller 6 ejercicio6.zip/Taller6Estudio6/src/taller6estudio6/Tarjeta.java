/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller6estudio6;

import java.util.Date;
import java.util.Random;

/**
 *
 * @author Alumno
 */
public class Tarjeta {
    private String nombre;
    private int alto;
    private int ancho;
    private int [][] tarjeta;

    public Tarjeta(String nombre, int alto, int ancho) {
        this.nombre = nombre;
        this.alto = alto;
        this.ancho = ancho;
        int[] lista=crearLista();
        this.tarjeta = crearTarjeta(lista);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAlt() {
        return alto;
    }

    public void setAlt(int alt) {
        this.alto = alto;
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public int[][] getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(int[][] tarjeta) {
        this.tarjeta = tarjeta;
    }

    
    
    public int[] crearLista(){
        Date semilla = new Date();
        Random rNum = new Random(semilla.getTime());
        int largo=this.ancho*this.alto;
        int[]lista=new int[largo];
        
        for(int i=0;i<largo;i++){
            lista[i]=(int)(100+rNum.nextInt(900));
        }
        return lista;
    }
    public int[] ordenarLista(int[] lista){
        
        for(int i=0;i<lista.length-1;i++){
            for(int j=0;j<lista.length-1;j++){
                if(lista[j]>lista[j+1]){
                    int aux=lista[j+1];
                    lista[j+1]=lista[j];
                    lista[j]=aux;
                }
            }
        }
        return lista;
    }
    public int[][] crearTarjeta(int[] lista){
        int[][] matriz = new int[this.alto][this.ancho];
        int contador=0;
        for(int i=0;i<this.alto;i++){
            for(int j=0;j<this.ancho;j++){
                matriz[i][j]=lista[contador];
                contador++;
            }
        }
        return matriz;
    }
    public void mostrarTarjeta(int[][] matriz){
        for(int i=0;i<matriz.length;i++){
            for(int j=0;j<matriz[i].length;i++){
            
            }
            System.out.print("");
        }
    }
}